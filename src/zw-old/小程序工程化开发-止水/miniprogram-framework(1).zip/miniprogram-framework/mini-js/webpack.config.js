const path = require('path');

const CopyPlugin = require('copy-webpack-plugin');
const WXAppPlugin = require('wxapp-webpack-plugin');

const { Targets } = WXAppPlugin;

module.exports = {
  target: Targets['Wechat'],
  entry: {
    app: './src/app.js',
  },
  output: {
    filename: '[name].js',
    publicPath: '/',
    path: path.resolve(__dirname, 'dist'),
  },
  devtool: false,
  watchOptions: {
    ignored: 'dist',
    aggregateTimeout: 300,
  },
  module: {
    rules: [
      {
        test: /\.js$/,
        include: /src/,
        exclude: /node_modules/,
        use: [
          'babel-loader',
        ],
      },
      {
        test: /\.less$/,
        include: /src/,
        exclude: /node_modules/,
        use: [
          {
            loader: 'file-loader',
            options: {
              name: '[path][name].wxss',
              context: path.resolve(__dirname, 'src'),
              useRelativePath: true,
            }
          },
          {
            loader: 'less-loader',
            options: {
              includePaths: [
                path.resolve(__dirname, 'src'),
                path.resolve(__dirname, 'styles'),
              ]
            }
          }
        ]
      },
      {
        test: /\.wxml$/,
        include: /src/,
        exclude: /node_modules/,
        use: [
          {
            loader: 'file-loader',
            options: {
              useRelativePath: true,
              name: '[path][name].wxml',
              context: path.resolve(__dirname, 'src'),
            }
          },
          {
            loader: 'wxml-loader',
            options: {
              root: path.resolve(__dirname, 'src'),
              enforceRelativePath: true,
            }
          }
        ]
      }
    ]
  },
  resolve: {
    modules: [path.resolve(__dirname, 'src'), 'node_modules'],
  },
  plugins: [
    new WXAppPlugin.default(),
    new CopyPlugin([
      { from: '**/*.json', context: path.resolve(__dirname, 'src') }
    ])
  ]
};
