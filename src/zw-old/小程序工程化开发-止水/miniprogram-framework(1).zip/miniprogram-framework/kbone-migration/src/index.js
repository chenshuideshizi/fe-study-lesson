export default function createApp() {
  document.body.innerHTML = 'hello kbone';
}

createApp();