module.exports = {
  entry: '/',
  router: {
    index: '/index',
  },
  redirect: {
    notFound: 'index',
    accessDenied: 'index'
  },
  generate: {
    autoBuildNpm: 'npm'
  },
  app: {
    navigationBarTitleText: 'hello kbone'
  },
  projectConfig: {
    projectname: 'hello kbone',
    appid: 'wxd764d23c7698a958'
  }
}