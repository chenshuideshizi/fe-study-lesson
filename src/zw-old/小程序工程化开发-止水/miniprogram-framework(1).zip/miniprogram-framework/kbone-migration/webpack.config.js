const path = require('path');
const webpack = require('webpack');

const miniCssExtractPlugin = require('mini-css-extract-plugin');
const MpWebpackPlugin = require('mp-webpack-plugin');

module.exports = {
  mode: 'production',
  target: 'web',
  entry: {
    index: path.resolve(__dirname, './src/index.js'),
  },
  output: {
    path: path.resolve(__dirname, './build/mp/common'),
    filename: '[name].js',
    library: 'createApp',
    libraryExport: 'default',
    libraryTarget: 'window',
  },
  module: {
    rules: [
      {
        test: /\.css$/,
        use: [
          miniCssExtractPlugin.loader,
          'css-loader'
        ]
      }
    ]
  },
  plugins: [
    new webpack.DefinePlugin({
      'process.env.isMiniprogram': process.env.isMiniprogram,
    }),
    new miniCssExtractPlugin({
      filename: '[name].wxss',
    }),
    new MpWebpackPlugin(require('./config')),
  ]
}