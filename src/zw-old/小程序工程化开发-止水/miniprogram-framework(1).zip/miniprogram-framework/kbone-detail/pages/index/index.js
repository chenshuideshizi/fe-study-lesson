Page({
  data: {
    tree: {
      childNodes: [
        {type: 'button', size: 'large', value: 'button'},
        {type: 'text', value: 'hello world'},
      ]
    }
  },
})
