interface Window {
    aa: boolean;
}