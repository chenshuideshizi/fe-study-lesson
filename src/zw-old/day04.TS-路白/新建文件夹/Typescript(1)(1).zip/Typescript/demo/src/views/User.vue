<template>
  <div class="user">
    <h1>This is an user page</h1>
  </div>
</template>
