const moduleA = require('./moduleA');

console.log(moduleA);