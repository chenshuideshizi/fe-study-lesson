export function add(a, b) {
  return a + b;
}

export function log() {
  return true;
}